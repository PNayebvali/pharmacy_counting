This is the directory where your program would find any test input files.
